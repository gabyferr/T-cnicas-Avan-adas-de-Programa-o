﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerancaEntregar
{
    internal class Trabalho : Automovel
    {
     public double peso { get; set; }

     public int eixos { get; set; } 

    public override double desconto()
    {
        return valor - 5000;
    }
}
}
