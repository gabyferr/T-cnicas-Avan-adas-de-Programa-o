﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerancaEntregar
{
    internal class Utilitario:Automovel

    {
        public int lugares { get; set; }   

        public string cor { get; set; }

        public override double desconto()

        {
            return valor - 1000;
        }
    }
}