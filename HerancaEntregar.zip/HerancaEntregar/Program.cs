﻿using HerancaEntregar;

class Program
{
    static void Main(string[] args)
    {

        Utilitario n1 = new Utilitario();
        n1.marca = "Nissan";
        n1.modelo = "Nissan Rogue Sport";
        n1.lugares = 5;
        n1.cor = "Azul";
        n1.valor = 100000;

        Trabalho n2 = new Trabalho();
        n2.marca = "BMW";
        n2.modelo = "BMW i8";
        n2.peso = 50000;
        n2.eixos = 5;
        n2.valor = 600000;
         
        Console.WriteLine("O automovel marca é " + n1.marca +" o modelo é " + n1.modelo);
        Console.WriteLine("\nA quantidade de lugares é " + n1.lugares + " e a cor é " +n1.cor);
        Console.WriteLine("\nO desconto é " + n1.desconto().ToString());

        Console.WriteLine("--------------------------------------------------\n");

        Console.WriteLine("O automovel marca é  " + n2.marca + " o modelo é " + n2.modelo);
        Console.WriteLine("\nO peso do carro é " + n2.peso+ ", a quantidade de eixos é "+n2.eixos);
        Console.WriteLine("\nO desconto é " + n2.desconto().ToString());
    }
}