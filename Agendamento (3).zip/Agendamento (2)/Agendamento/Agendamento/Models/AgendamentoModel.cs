﻿using System.ComponentModel.DataAnnotations;

namespace Agendamento.Models
{
    public class AgendamentoModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Campo inválido")]
        public string NomeCliente { get; set; }

        [Required(ErrorMessage = "Campo inválido")]
        public string NomeProfissional { get; set; }

        [Required(ErrorMessage = "Campo inválido")]
        public string Procedimento { get; set; }

        public DateTime Data { get; set; } = DateTime.Now;

        public DateTime Horario { get; set; } = DateTime.Now;
    }
}
