﻿using Microsoft.AspNetCore.Mvc;
using Agendamento.Data;
using Agendamento.Models;
using System.Net.Http.Headers;

namespace Agendamento.Controllers
{
    public class AgendamentoController : Controller
    {
        readonly private ApplicationDbContext _db;

        public AgendamentoController(ApplicationDbContext db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            IEnumerable<AgendamentoModel> agendamento = _db.Agendamento;
            return View(agendamento);
        }

        public IActionResult Cadastrar()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Cadastrar(AgendamentoModel agendamento)
        {
            if (ModelState.IsValid)
            {
                _db.Agendamento.Add(agendamento);
                _db.SaveChanges();

                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        public IActionResult Editar(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            AgendamentoModel agendamento = _db.Agendamento.FirstOrDefault(x => x.Id == id);

            if (agendamento == null)
            {
                return NotFound();
            }

            return View(agendamento);
        }

        [HttpPost]
        public IActionResult Editar(AgendamentoModel agendamento)
        {
            if (ModelState.IsValid)
            {
                _db.Agendamento.Update(agendamento);
                _db.SaveChanges();

                return RedirectToAction("Index");
            }
            return View(agendamento);
        }

        [HttpGet]
        public IActionResult Excluir(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            AgendamentoModel agendamento = _db.Agendamento.FirstOrDefault(x => x.Id == id);

            if (agendamento == null)
            {
                return NotFound();
            }

            return View(agendamento);
        }

        [HttpPost]
        public IActionResult Excluir(AgendamentoModel agendamento)
        {
            if (agendamento == null)
            {
                return NotFound();
            }
            _db.Agendamento.Remove(agendamento);
            _db.SaveChanges();

            return RedirectToAction("Index");
        }

    }
}