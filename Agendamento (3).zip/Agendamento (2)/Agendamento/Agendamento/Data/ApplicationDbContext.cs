﻿using Microsoft.EntityFrameworkCore;
using Agendamento.Models;
using System.Collections.Generic;

namespace Agendamento.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        { }

        public DbSet<AgendamentoModel> Agendamento { get; set; }
    }
}

